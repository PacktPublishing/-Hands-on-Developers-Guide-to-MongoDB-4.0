module.exports = {
  testEnvironment: "node"
};
